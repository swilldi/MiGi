//
//  MiGiApp.swift
//  MiGi
//
//  Created by Дмитрий on 15.01.2024.
//

import SwiftUI

@main
struct MiGiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
